import { useEffect, useMemo, useState } from "react";
import { Plus, Search, Pencil, Trash2 } from "lucide-react";
import api from "../api";
import LeadModal from "../components/LeadModal";

const stages=["New","Contacted","Qualified","Proposal","Won","Lost"];
export default function Leads() {
  const [leads,setLeads]=useState([]); const [search,setSearch]=useState(""); const [stage,setStage]=useState("All");
  const [modal,setModal]=useState(null); const [error,setError]=useState("");
  async function load(){try{const {data}=await api.get("/leads");setLeads(data.leads);setError("");}catch(e){setError(e.response?.data?.message||"Could not load leads.");}}
  useEffect(()=>{load();},[]);
  const filtered=useMemo(()=>leads.filter(l=>(stage==="All"||l.stage===stage)&&`${l.name} ${l.company} ${l.email}`.toLowerCase().includes(search.toLowerCase())),[leads,stage,search]);
  async function remove(id){if(!confirm("Delete this lead and its activity history?"))return;try{await api.delete(`/leads/${id}`);load();}catch(e){setError(e.response?.data?.message||"Delete failed.");}}
  return <><div className="page-heading"><div><p className="eyebrow">CUSTOMER RELATIONSHIPS</p><h1>Leads</h1><p>Manage prospects and keep every opportunity moving.</p></div><button className="btn" onClick={()=>setModal({})}><Plus size={17}/> Add lead</button></div>
    {error&&<p className="error-text">{error}</p>}
    <section className="panel">
      <div className="toolbar"><div className="searchbox"><Search size={17}/><input placeholder="Search name, company or email..." value={search} onChange={e=>setSearch(e.target.value)}/></div><select value={stage} onChange={e=>setStage(e.target.value)}><option>All</option>{stages.map(s=><option key={s}>{s}</option>)}</select></div>
      <div className="table-scroll"><table className="data-table"><thead><tr><th>Contact</th><th>Company</th><th>Stage</th><th>Deal value</th><th>Owner</th><th>Actions</th></tr></thead><tbody>
        {filtered.map(l=><tr key={l._id}><td><strong>{l.name}</strong><small>{l.email||l.phone||"No contact details"}</small></td><td>{l.company||"—"}</td><td><span className={`stage stage-${l.stage.toLowerCase()}`}>{l.stage}</span></td><td>${Number(l.value).toLocaleString()}</td><td>{l.owner?.name||"—"}</td><td><div className="actions"><button className="icon-btn" title="Edit" onClick={()=>setModal(l)}><Pencil size={16}/></button><button className="icon-btn danger" title="Delete" onClick={()=>remove(l._id)}><Trash2 size={16}/></button></div></td></tr>)}
        {filtered.length===0&&<tr><td colSpan="6" className="empty">No leads found. Try another search or add a lead.</td></tr>}
      </tbody></table></div>
    </section>
    {modal&&<LeadModal lead={modal._id?modal:null} onClose={()=>setModal(null)} onSaved={()=>{setModal(null);load();}}/>}
  </>;
}
