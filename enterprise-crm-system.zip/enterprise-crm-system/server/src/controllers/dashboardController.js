import Lead from "../models/Lead.js";
import Activity from "../models/Activity.js";

export async function getDashboard(req, res, next) {
  try {
    const filter = req.user.role === "admin" ? {} : { owner: req.user._id };
    const [totalLeads, wonLeads, pipeline, stageCounts, recentActivities] = await Promise.all([
      Lead.countDocuments(filter),
      Lead.countDocuments({ ...filter, stage: "Won" }),
      Lead.aggregate([{ $match: { ...filter, stage: { $nin: ["Won", "Lost"] } } }, { $group: { _id: null, total: { $sum: "$value" } } }]),
      Lead.aggregate([{ $match: filter }, { $group: { _id: "$stage", count: { $sum: 1 }, value: { $sum: "$value" } } }]),
      Activity.find(req.user.role === "admin" ? {} : { user: req.user._id })
        .populate("user", "name").populate("lead", "name").sort({ createdAt: -1 }).limit(8)
    ]);
    res.json({
      totalLeads, wonLeads, pipelineValue: pipeline[0]?.total || 0,
      stageCounts, recentActivities
    });
  } catch (err) { next(err); }
}
