import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Leads from "./pages/Leads";
import Pipeline from "./pages/Pipeline";
import Users from "./pages/Users";

export default function App(){
  const {user,loading}=useAuth();
  if(loading)return <div className="center">Loading CRM...</div>;
  return <Routes>
    <Route path="/login" element={user?<Navigate to="/dashboard"/>:<Login/>}/>
    <Route path="/register" element={user?<Navigate to="/dashboard"/>:<Register/>}/>
    <Route element={<ProtectedRoute><Layout/></ProtectedRoute>}>
      <Route path="/dashboard" element={<Dashboard/>}/>
      <Route path="/leads" element={<Leads/>}/>
      <Route path="/pipeline" element={<Pipeline/>}/>
      <Route path="/users" element={<ProtectedRoute adminOnly><Users/></ProtectedRoute>}/>
    </Route>
    <Route path="*" element={<Navigate to={user?"/dashboard":"/login"} replace/>}/>
  </Routes>;
}
