# Enterprise CRM System — Northstar CRM

A full-stack customer relationship management starter project built with React, Node.js, Express, MongoDB and REST APIs.

## Features

- User registration and login with JWT authentication
- Admin and Sales roles with protected routes
- Lead creation, editing, deletion, search and stage filtering
- Sales pipeline with six deal stages
- Dashboard with lead counts, won deals, pipeline value and activity feed
- Lead activity records: notes, calls, emails, meetings and tasks
- Admin team page to list users and change roles
- Responsive React interface

## Requirements

- Node.js 20 LTS or newer
- npm
- MongoDB Community Server, or a MongoDB Atlas account
- VS Code (recommended)

## 1. Install Node.js

Download the LTS version from https://nodejs.org/. Open a new terminal:

```bash
node -v
npm -v
```

## 2. Install and start MongoDB

Option A — Local MongoDB:
- Install MongoDB Community Server: https://www.mongodb.com/try/download/community
- Start the MongoDB service.
- The default local connection is `mongodb://127.0.0.1:27017/enterprise_crm`.

Option B — MongoDB Atlas:
- Create a free cluster at https://www.mongodb.com/atlas
- Create a database user and allow your IP in Network Access.
- Copy the Node.js connection string and put it in `server/.env`.

## 3. Extract and open the project

Extract `enterprise-crm-system.zip` and open the `enterprise-crm-system` folder in VS Code.

## 4. Configure backend environment

Copy `server/.env.example` to `server/.env`.

Windows PowerShell:

```powershell
Copy-Item server/.env.example server/.env
```

Windows Command Prompt:

```cmd
copy server\.env.example server\.env
```

Edit `server/.env`:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/enterprise_crm
JWT_SECRET=replace_with_a_long_random_secret_value
CLIENT_URL=http://localhost:5173
```

For Atlas, replace `MONGODB_URI` with your Atlas connection string. Keep credentials private.

## 5. Install all dependencies

From the root project folder:

```bash
npm install
```

## 6. Create the first admin account

Registration intentionally creates Sales users only. To create the first administrator, register an account using the app, then promote it once using this one-time script.

Create `server/src/createAdmin.js`:

```js
import "dotenv/config";
import mongoose from "mongoose";
import User from "./models/User.js";

await mongoose.connect(process.env.MONGODB_URI);
const email = "your-email@example.com"; // change this
const user = await User.findOneAndUpdate(
  { email },
  { role: "admin" },
  { new: true }
);
console.log(user ? `Admin enabled: ${user.email}` : "User not found. Register this email first.");
await mongoose.disconnect();
```

Then run from the root folder:

```bash
node server/src/createAdmin.js
```

Delete `createAdmin.js` after use. This one-time promotion script should not be exposed as a public API.

## 7. Start the project

Open a terminal in the root folder:

```bash
npm run dev
```

This starts:
- Backend API: http://localhost:5000
- React frontend: http://localhost:5173

Open http://localhost:5173 in your browser and register or sign in.

## 8. Use the application

1. Register a sales account.
2. Promote one account to admin using step 6.
3. Sign in again.
4. Add leads from the Leads page.
5. Update their stage in Sales Pipeline.
6. Open a lead and edit it to update contact/deal information.
7. Use Team Access as admin to promote or demote team members.
8. Dashboard shows totals, pipeline stage counts and recent activities.

## API overview

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register Sales account |
| POST | `/api/auth/login` | Public | Login |
| GET | `/api/auth/me` | Signed in | Current user |
| GET | `/api/leads` | Signed in | List visible leads |
| POST | `/api/leads` | Signed in | Create lead |
| PATCH | `/api/leads/:id` | Owner/Admin | Update lead |
| DELETE | `/api/leads/:id` | Owner/Admin | Delete lead |
| GET | `/api/leads/:leadId/activities` | Owner/Admin | List lead activities |
| POST | `/api/leads/:leadId/activities` | Owner/Admin | Add activity |
| GET | `/api/dashboard` | Signed in | Dashboard metrics |
| GET | `/api/users` | Admin | List users |
| PATCH | `/api/users/:id/role` | Admin | Change role |

All protected routes require `Authorization: Bearer <token>`.

## Project structure

```text
enterprise-crm-system/
├── server/
│   ├── src/
│   │   ├── config/db.js
│   │   ├── controllers/
│   │   ├── middleware/
│   │   ├── models/
│   │   ├── routes/
│   │   └── server.js
│   ├── .env.example
│   └── package.json
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── context/
│   │   ├── pages/
│   │   ├── App.jsx
│   │   ├── api.js
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── package.json
└── README.md
```

## Troubleshooting

- `ECONNREFUSED 127.0.0.1:27017`: MongoDB service is not running. Start it or use a valid Atlas URI.
- `MONGODB_URI is missing`: confirm `server/.env` exists and variable is spelled correctly.
- CORS error: confirm `CLIENT_URL=http://localhost:5173` in `server/.env`, then restart backend.
- Login returns 401: check email/password and confirm backend is connected to the same MongoDB database.
- Port in use: change `PORT` in `server/.env` or stop the other process.
- API is unavailable: verify backend terminal says `CRM API running at http://localhost:5000`.

## Production security checklist

This is an educational MVP. Before production, add email verification, password reset, stronger token storage (prefer secure httpOnly cookies), CSRF protections if using cookies, input validation, audit logs, pagination, tests, monitoring, backups, HTTPS, and a formal process for provisioning the first admin. Review role permissions and data retention before storing real customer data.
