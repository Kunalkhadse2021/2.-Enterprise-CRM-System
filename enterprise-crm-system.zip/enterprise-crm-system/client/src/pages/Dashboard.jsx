import { useEffect, useState } from "react";
import { Users, Trophy, DollarSign, Target } from "lucide-react";
import api from "../api";

export default function Dashboard() {
  const [data,setData]=useState(null); const [error,setError]=useState("");
  useEffect(()=>{api.get("/dashboard").then(r=>setData(r.data)).catch(e=>setError(e.response?.data?.message||"Could not load dashboard."));},[]);
  if(error)return <p className="error-text">{error}</p>;
  if(!data)return <p>Loading dashboard...</p>;
  const stats=[
    {label:"Total leads",value:data.totalLeads,icon:Users,tone:"blue"},
    {label:"Deals won",value:data.wonLeads,icon:Trophy,tone:"green"},
    {label:"Open pipeline",value:`$${Number(data.pipelineValue).toLocaleString()}`,icon:DollarSign,tone:"purple"},
    {label:"Win rate",value:`${data.totalLeads?Math.round(data.wonLeads/data.totalLeads*100):0}%`,icon:Target,tone:"orange"}
  ];
  const max=Math.max(1,...data.stageCounts.map(x=>x.count));
  return <><div className="page-heading"><div><p className="eyebrow">OVERVIEW</p><h1>Sales dashboard</h1><p>Track your leads, deals and team activity.</p></div></div>
    <section className="stat-grid">{stats.map(s=><article className="stat-card" key={s.label}><div className={`stat-icon ${s.tone}`}><s.icon size={20}/></div><p>{s.label}</p><strong>{s.value}</strong></article>)}</section>
    <section className="panel-grid">
      <article className="panel"><div className="panel-title"><h2>Pipeline by stage</h2><span>Lead count</span></div>
        {data.stageCounts.length===0?<p className="empty">No leads yet. Add your first lead to see pipeline metrics.</p>:data.stageCounts.map(s=><div className="pipeline-row" key={s._id}><div><span>{s._id}</span><b>{s.count}</b></div><div className="progress"><span style={{width:`${s.count/max*100}%`}}/></div></div>)}
      </article>
      <article className="panel"><div className="panel-title"><h2>Recent activity</h2></div>
        {data.recentActivities.length===0?<p className="empty">No activities recorded yet.</p>:data.recentActivities.map(a=><div className="activity-row" key={a._id}><div className="activity-dot"/><div><strong>{a.type}</strong><p>{a.description}</p><small>{a.lead?.name||"Lead"} · {a.user?.name||"Team member"} · {new Date(a.createdAt).toLocaleDateString()}</small></div></div>)}
      </article>
    </section>
  </>;
}
