import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const {register} = useAuth(); const navigate=useNavigate();
  const [form,setForm]=useState({name:"",email:"",password:""}); const [error,setError]=useState("");
  function change(e){setForm({...form,[e.target.name]:e.target.value});}
  async function submit(e){e.preventDefault();setError("");try{await register(form.name,form.email,form.password);navigate("/dashboard");}catch(err){setError(err.response?.data?.message||"Registration failed.");}}
  return <div className="auth-page"><form className="auth-card" onSubmit={submit}>
    <div className="brand auth-brand">Northstar <span>CRM</span></div><h1>Create your account</h1><p>New accounts receive the Sales role.</p>
    <label>Full name<input name="name" required value={form.name} onChange={change}/></label>
    <label>Email<input name="email" type="email" required value={form.email} onChange={change}/></label>
    <label>Password (minimum 8 characters)<input name="password" type="password" minLength="8" required value={form.password} onChange={change}/></label>
    {error&&<p className="error-text">{error}</p>}<button className="btn wide">Create account</button>
    <small>Already registered? <Link to="/login">Sign in</Link></small>
  </form></div>;
}
