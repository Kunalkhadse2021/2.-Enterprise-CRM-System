import mongoose from "mongoose";

const activitySchema = new mongoose.Schema({
  lead: { type: mongoose.Schema.Types.ObjectId, ref: "Lead", required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  type: { type: String, enum: ["Note", "Call", "Email", "Meeting", "Task"], default: "Note" },
  description: { type: String, required: true, trim: true }
}, { timestamps: true });

export default mongoose.model("Activity", activitySchema);
