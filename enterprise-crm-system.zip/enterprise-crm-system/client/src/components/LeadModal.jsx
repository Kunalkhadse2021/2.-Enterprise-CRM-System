import { useState } from "react";
import api from "../api";

const initial = {name:"",company:"",email:"",phone:"",source:"Website",stage:"New",value:0,notes:""};
export default function LeadModal({lead,onClose,onSaved}) {
  const [form,setForm] = useState(lead ? {...initial,...lead} : initial);
  const [error,setError] = useState("");
  const [busy,setBusy] = useState(false);
  function change(e) { setForm({...form,[e.target.name]:e.target.value}); }
  async function submit(e) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      if (lead?._id) await api.patch(`/leads/${lead._id}`,form);
      else await api.post("/leads",form);
      onSaved();
    } catch(err) { setError(err.response?.data?.message || "Could not save lead."); }
    finally { setBusy(false); }
  }
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}>
    <form className="modal" onSubmit={submit}>
      <div className="modal-head"><h2>{lead ? "Edit lead" : "Add new lead"}</h2><button type="button" className="icon-btn" onClick={onClose}>×</button></div>
      <div className="form-grid">
        <label>Contact name *<input name="name" required value={form.name} onChange={change}/></label>
        <label>Company<input name="company" value={form.company} onChange={change}/></label>
        <label>Email<input type="email" name="email" value={form.email} onChange={change}/></label>
        <label>Phone<input name="phone" value={form.phone} onChange={change}/></label>
        <label>Lead source<select name="source" value={form.source} onChange={change}><option>Website</option><option>Referral</option><option>LinkedIn</option><option>Event</option><option>Cold call</option></select></label>
        <label>Deal stage<select name="stage" value={form.stage} onChange={change}>{["New","Contacted","Qualified","Proposal","Won","Lost"].map(s=><option key={s}>{s}</option>)}</select></label>
        <label>Deal value (USD)<input type="number" min="0" name="value" value={form.value} onChange={change}/></label>
        <label className="full">Notes<textarea name="notes" rows="3" value={form.notes} onChange={change}/></label>
      </div>
      {error&&<p className="error-text">{error}</p>}
      <div className="modal-actions"><button type="button" className="btn btn-light" onClick={onClose}>Cancel</button><button className="btn" disabled={busy}>{busy?"Saving...":"Save lead"}</button></div>
    </form>
  </div>;
}
