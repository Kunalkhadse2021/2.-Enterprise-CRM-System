import User from "../models/User.js";

export async function listUsers(req, res, next) {
  try {
    const users = await User.find().select("name email role createdAt").sort({ createdAt: -1 });
    res.json({ users });
  } catch (err) { next(err); }
}

export async function updateUserRole(req, res, next) {
  try {
    if (req.params.id === String(req.user._id)) return res.status(400).json({ message: "You cannot change your own role." });
    const { role } = req.body;
    if (!["admin", "sales"].includes(role)) return res.status(400).json({ message: "Role must be admin or sales." });
    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true, runValidators: true }).select("name email role");
    if (!user) return res.status(404).json({ message: "User not found." });
    res.json({ user });
  } catch (err) { next(err); }
}
