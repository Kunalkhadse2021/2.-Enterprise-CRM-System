import { Router } from "express";
import { listUsers, updateUserRole } from "../controllers/userController.js";
import { protect, allowRoles } from "../middleware/auth.js";
const router = Router();
router.use(protect, allowRoles("admin"));
router.get("/", listUsers);
router.patch("/:id/role", updateUserRole);
export default router;
