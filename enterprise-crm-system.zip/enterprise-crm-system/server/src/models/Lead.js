import mongoose from "mongoose";

const leadSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  company: { type: String, trim: true, default: "" },
  email: { type: String, lowercase: true, trim: true, default: "" },
  phone: { type: String, trim: true, default: "" },
  source: { type: String, default: "Website" },
  stage: { type: String, enum: ["New", "Contacted", "Qualified", "Proposal", "Won", "Lost"], default: "New" },
  value: { type: Number, min: 0, default: 0 },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  notes: { type: String, default: "" }
}, { timestamps: true });

export default mongoose.model("Lead", leadSchema);
