import Lead from "../models/Lead.js";
import Activity from "../models/Activity.js";

const stages = ["New", "Contacted", "Qualified", "Proposal", "Won", "Lost"];

function visibilityFilter(user) {
  return user.role === "admin" ? {} : { owner: user._id };
}

export async function listLeads(req, res, next) {
  try {
    const filter = { ...visibilityFilter(req.user) };
    if (req.query.stage && stages.includes(req.query.stage)) filter.stage = req.query.stage;
    if (req.query.search) {
      const term = String(req.query.search).trim();
      filter.$or = ["name", "company", "email"].map(field => ({ [field]: { $regex: term, $options: "i" } }));
    }
    const leads = await Lead.find(filter).populate("owner", "name email").sort({ updatedAt: -1 });
    res.json({ leads });
  } catch (err) { next(err); }
}

export async function createLead(req, res, next) {
  try {
    const { name, company, email, phone, source, stage, value, notes } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: "Lead name is required." });
    const lead = await Lead.create({ name, company, email, phone, source, stage, value, notes, owner: req.user._id });
    await lead.populate("owner", "name email");
    res.status(201).json({ lead });
  } catch (err) { next(err); }
}

export async function updateLead(req, res, next) {
  try {
    const lead = await Lead.findOne({ _id: req.params.id, ...visibilityFilter(req.user) });
    if (!lead) return res.status(404).json({ message: "Lead not found." });
    const allowed = ["name", "company", "email", "phone", "source", "stage", "value", "notes"];
    for (const key of allowed) if (req.body[key] !== undefined) lead[key] = req.body[key];
    await lead.save();
    await lead.populate("owner", "name email");
    res.json({ lead });
  } catch (err) { next(err); }
}

export async function deleteLead(req, res, next) {
  try {
    const lead = await Lead.findOneAndDelete({ _id: req.params.id, ...visibilityFilter(req.user) });
    if (!lead) return res.status(404).json({ message: "Lead not found." });
    await Activity.deleteMany({ lead: lead._id });
    res.json({ message: "Lead deleted." });
  } catch (err) { next(err); }
}
