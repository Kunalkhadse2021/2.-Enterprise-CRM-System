import { useEffect, useState } from "react";
import api from "../api";
const stages=["New","Contacted","Qualified","Proposal","Won","Lost"];
export default function Pipeline(){
  const [leads,setLeads]=useState([]);const [error,setError]=useState("");
  async function load(){try{const {data}=await api.get("/leads");setLeads(data.leads);}catch(e){setError(e.response?.data?.message||"Could not load pipeline.");}}
  useEffect(()=>{load();},[]);
  async function move(id,stage){try{await api.patch(`/leads/${id}`,{stage});load();}catch(e){setError(e.response?.data?.message||"Could not update stage.");}}
  return <><div className="page-heading"><div><p className="eyebrow">DEAL MANAGEMENT</p><h1>Sales pipeline</h1><p>Move opportunities through each sales stage.</p></div></div>
    {error&&<p className="error-text">{error}</p>}
    <div className="kanban">{stages.map(stage=>{const group=leads.filter(l=>l.stage===stage);return <section className="kanban-col" key={stage}><div className="kanban-head"><strong>{stage}</strong><span>{group.length}</span></div>
      {group.map(l=><article className="deal-card" key={l._id}><strong>{l.name}</strong><p>{l.company||"Individual"}</p><b>${Number(l.value).toLocaleString()}</b><select aria-label={`Change ${l.name} stage`} value={l.stage} onChange={e=>move(l._id,e.target.value)}>{stages.map(s=><option key={s}>{s}</option>)}</select></article>)}
      {group.length===0&&<p className="empty">No deals</p>}
    </section>;})}</div>
  </>;
}
