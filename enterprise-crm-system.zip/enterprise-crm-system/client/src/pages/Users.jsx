import { useEffect,useState } from "react";
import api from "../api";
import { useAuth } from "../context/AuthContext";

export default function Users(){
  const [users,setUsers]=useState([]);const [error,setError]=useState("");const {user:me}=useAuth();
  async function load(){try{const {data}=await api.get("/users");setUsers(data.users);}catch(e){setError(e.response?.data?.message||"Could not load team.");}}
  useEffect(()=>{load();},[]);
  async function changeRole(id,role){try{await api.patch(`/users/${id}/role`,{role});load();}catch(e){setError(e.response?.data?.message||"Could not update role.");}}
  return <><div className="page-heading"><div><p className="eyebrow">ADMINISTRATION</p><h1>Team access</h1><p>Manage administrator and sales permissions.</p></div></div>
    {error&&<p className="error-text">{error}</p>}
    <section className="panel"><div className="table-scroll"><table className="data-table"><thead><tr><th>Team member</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead><tbody>
      {users.map(u=><tr key={u._id}><td><strong>{u.name}</strong></td><td>{u.email}</td><td>{u._id===(me.id||me._id)?<span className="stage stage-qualified">{u.role} (you)</span>:<select value={u.role} onChange={e=>changeRole(u._id,e.target.value)}><option value="sales">Sales</option><option value="admin">Admin</option></select>}</td><td>{new Date(u.createdAt).toLocaleDateString()}</td></tr>)}
    </tbody></table></div></section>
  </>;
}
