import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { LayoutDashboard, Users, KanbanSquare, LogOut, UserCog } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Layout() {
  const {user,logout} = useAuth();
  const navigate = useNavigate();
  function signOut() { logout(); navigate("/login"); }
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand">Northstar <span>CRM</span></div>
      <div className="profile"><div className="avatar">{user?.name?.[0]?.toUpperCase()}</div><div><strong>{user?.name}</strong><small>{user?.role}</small></div></div>
      <nav>
        <NavLink to="/dashboard"><LayoutDashboard size={18}/> Dashboard</NavLink>
        <NavLink to="/leads"><Users size={18}/> Leads</NavLink>
        <NavLink to="/pipeline"><KanbanSquare size={18}/> Sales pipeline</NavLink>
        {user?.role==="admin" && <NavLink to="/users"><UserCog size={18}/> Team access</NavLink>}
      </nav>
      <button className="logout" onClick={signOut}><LogOut size={17}/> Sign out</button>
    </aside>
    <main className="main"><header className="topbar"><span>Enterprise workspace</span><span className="top-user">{user?.email}</span></header><div className="content"><Outlet/></div></main>
  </div>;
}
