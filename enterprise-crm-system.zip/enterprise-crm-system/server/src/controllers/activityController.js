import Activity from "../models/Activity.js";
import Lead from "../models/Lead.js";

export async function listActivities(req, res, next) {
  try {
    const lead = await Lead.findOne({ _id: req.params.leadId, ...(req.user.role === "admin" ? {} : { owner: req.user._id }) });
    if (!lead) return res.status(404).json({ message: "Lead not found." });
    const activities = await Activity.find({ lead: lead._id }).populate("user", "name").sort({ createdAt: -1 });
    res.json({ activities });
  } catch (err) { next(err); }
}

export async function createActivity(req, res, next) {
  try {
    const lead = await Lead.findOne({ _id: req.params.leadId, ...(req.user.role === "admin" ? {} : { owner: req.user._id }) });
    if (!lead) return res.status(404).json({ message: "Lead not found." });
    if (!req.body.description?.trim()) return res.status(400).json({ message: "Activity description is required." });
    const activity = await Activity.create({
      lead: lead._id, user: req.user._id,
      type: req.body.type || "Note", description: req.body.description
    });
    await activity.populate("user", "name");
    res.status(201).json({ activity });
  } catch (err) { next(err); }
}
