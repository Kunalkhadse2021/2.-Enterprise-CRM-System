import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const {login} = useAuth(); const navigate = useNavigate();
  const [email,setEmail] = useState("admin@northstarcrm.com");
  const [password,setPassword] = useState("Admin123!");
  const [error,setError] = useState(""); const [busy,setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setBusy(true); setError("");
    try { const user = await login(email,password); navigate(user.role==="admin"?"/dashboard":"/dashboard"); }
    catch(err) { setError(err.response?.data?.message || "Login failed."); }
    finally { setBusy(false); }
  }
  return <div className="auth-page"><form className="auth-card" onSubmit={submit}>
    <div className="brand auth-brand">Northstar <span>CRM</span></div><h1>Welcome back</h1><p>Sign in to manage your customer relationships.</p>
    <label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label>
    <label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></label>
    {error&&<p className="error-text">{error}</p>}<button className="btn wide" disabled={busy}>{busy?"Signing in...":"Sign in"}</button>
    <small>New to the workspace? <Link to="/register">Create an account</Link></small>
    <small className="demo-hint">Demo admin: admin@northstarcrm.com / Admin123!</small>
  </form></div>;
}
